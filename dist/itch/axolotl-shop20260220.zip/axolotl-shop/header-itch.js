(function(){var p=document.getElementById('site-header');if(p)p.innerHTML='';})();
